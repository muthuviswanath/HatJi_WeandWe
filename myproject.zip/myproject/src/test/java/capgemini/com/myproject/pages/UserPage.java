package capgemini.com.myproject.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import capgemini.com.myproject.utilities.ExtentReportUtil;
import capgemini.com.myproject.utilities.WaitUtil;

public class UserPage extends BasePage{
	By user_profile_name = By.xpath("//main[@id='workspace']//p[contains(text(),'MANDALAPU VENKATA SRINIVASA SAI RAM')]");
	
	public UserPage(WebDriver driver) {
		super(driver);
	}

	public void userProfileClick() {
		WaitUtil.clickWhenReady(user_profile_name);
		ExtentReportUtil.logStep("After clicking user profile", true);
	}
}
