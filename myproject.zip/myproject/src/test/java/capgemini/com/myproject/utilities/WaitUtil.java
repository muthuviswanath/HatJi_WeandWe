package capgemini.com.myproject.utilities;


import capgemini.com.myproject.factory.DriverFactory;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;

import java.time.Duration;
import java.util.function.Function;

public class WaitUtil {

    private static final int DEFAULT_TIMEOUT = 10;
    private static final int POLLING_INTERVAL = 500;

    private static WebDriverWait getWait(int timeout) {
        return new WebDriverWait(
                DriverFactory.getDriver(),
                Duration.ofSeconds(timeout),
                Duration.ofMillis(POLLING_INTERVAL)
        );
    }

    // 🔹 Wait for element to be visible
    public static WebElement waitForVisibility(By locator) {
        return getWait(DEFAULT_TIMEOUT)
                .until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    public static WebElement waitForVisibility(By locator, int timeout) {
        return getWait(timeout)
                .until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    // 🔹 Wait for element to be clickable
    public static WebElement waitForClickable(By locator) {
        return getWait(DEFAULT_TIMEOUT)
                .until(ExpectedConditions.elementToBeClickable(locator));
    }

    public static WebElement waitForClickable(By locator, int timeout) {
        return getWait(timeout)
                .until(ExpectedConditions.elementToBeClickable(locator));
    }

    // 🔹 Wait for presence (DOM only)
    public static WebElement waitForPresence(By locator) {
        return getWait(DEFAULT_TIMEOUT)
                .until(ExpectedConditions.presenceOfElementLocated(locator));
    }

    // 🔹 Wait for invisibility
    public static boolean waitForInvisibility(By locator) {
        return getWait(DEFAULT_TIMEOUT)
                .until(ExpectedConditions.invisibilityOfElementLocated(locator));
    }

    // 🔹 Wait for text to be present
    public static boolean waitForText(By locator, String text) {
        return getWait(DEFAULT_TIMEOUT)
                .until(ExpectedConditions.textToBePresentInElementLocated(locator, text));
    }

    // 🔹 Wait for title
    public static boolean waitForTitleContains(String title) {
        return getWait(DEFAULT_TIMEOUT)
                .until(ExpectedConditions.titleContains(title));
    }

    // 🔹 Wait for URL
    public static boolean waitForUrlContains(String url) {
        return getWait(DEFAULT_TIMEOUT)
                .until(ExpectedConditions.urlContains(url));
    }

    // 🔹 Fluent Wait (advanced custom wait)
    public static <T> T fluentWait(Function<WebDriver, T> condition, int timeout) {

        Wait<WebDriver> wait = new FluentWait<>(DriverFactory.getDriver())
                .withTimeout(Duration.ofSeconds(timeout))
                .pollingEvery(Duration.ofMillis(POLLING_INTERVAL))
                .ignoring(NoSuchElementException.class)
                .ignoring(StaleElementReferenceException.class);

        return wait.until(condition);
    }

    // 🔹 Wait for element and click (most used in real projects)
    public static void clickWhenReady(By locator) {
        waitForClickable(locator).click();
    }

    // 🔹 Wait for element and send keys
    public static void sendKeysWhenVisible(By locator, String text) {
        WebElement element = waitForVisibility(locator);
        element.clear();
        element.sendKeys(text);
    }

    // 🔹 Hard wait (use ONLY if absolutely needed)
    public static void hardWait(int seconds) {
        try {
            Thread.sleep(seconds * 1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}