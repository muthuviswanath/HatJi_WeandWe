package capgemini.com.myproject.utilities;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class ExtentReportListener implements ITestListener {

    @Override
    public void onStart(ITestContext context) {
        ExtentReportUtil.initReport();
    }

    @Override
    public void onFinish(ITestContext context) {
        ExtentReportUtil.flushReport();
    }

    @Override
    public void onTestStart(ITestResult result) {
        ExtentReportUtil.startTest(result.getMethod().getMethodName());
        ExtentReportUtil.logStep("Test Started: " + result.getMethod().getMethodName(), false);
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        ExtentReportUtil.logPass("Test Passed: " + result.getMethod().getMethodName());
    }

    @Override
    public void onTestFailure(ITestResult result) {
        ExtentReportUtil.logFail("Test Failed: " + result.getMethod().getMethodName(), result.getThrowable());
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        ExtentReportUtil.logSkip("Test Skipped: " + result.getMethod().getMethodName());
    }
}
