package capgemini.com.myproject.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import capgemini.com.myproject.utilities.ExtentReportUtil;
import capgemini.com.myproject.utilities.WaitUtil;

public class LoginPage extends BasePage{

	private By username_txtbox = By.xpath("//input[@id='username']");
	private By password_txtbox = By.xpath("//input[@id='password']");
	private By sign_in_button = By.xpath("//button[contains(text(),'Sign in')]");
	
	public LoginPage(WebDriver driver) {
		super(driver);

	}
	
	public void loginToLinkedin(String username, String password) {
		//sairammandalapu256@gmail.com
		WaitUtil.sendKeysWhenVisible(username_txtbox, username);
		//savitri1sai
		ExtentReportUtil.logStep("After entering username", true);
		WaitUtil.sendKeysWhenVisible(password_txtbox, password);
		ExtentReportUtil.logStep("After entering password", true);
		WaitUtil.clickWhenReady(sign_in_button);
		ExtentReportUtil.logStep("After clicking signin", true);
	}

}
