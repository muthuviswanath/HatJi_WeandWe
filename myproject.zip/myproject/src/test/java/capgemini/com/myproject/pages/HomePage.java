package capgemini.com.myproject.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import capgemini.com.myproject.utilities.ExtentReportUtil;
import capgemini.com.myproject.utilities.WaitUtil;

public class HomePage extends BasePage{

	private By signin_button = By.xpath("//a[@data-test-id='home-hero-sign-in-cta']");

	public HomePage(WebDriver driver) {
		super(driver);
	}
	
	public void clickSignin() {
		WaitUtil.clickWhenReady(signin_button);
		ExtentReportUtil.logStep("After clicking Sign in button", true);
	}
}
