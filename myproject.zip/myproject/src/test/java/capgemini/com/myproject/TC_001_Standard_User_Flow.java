package capgemini.com.myproject;

import org.testng.annotations.Test;

import capgemini.com.myproject.base.BaseTest;
import capgemini.com.myproject.pages.HomePage;
import capgemini.com.myproject.pages.LoginPage;
import capgemini.com.myproject.pages.UserPage;
import capgemini.com.myproject.utilities.JsonUtil;

public class TC_001_Standard_User_Flow extends BaseTest {

    @Test
    public void Standard_User_Flow() {
        HomePage homepage = new HomePage(driver);
        homepage.clickSignin();
    	LoginPage login = new LoginPage(driver);
    	login.loginToLinkedin(JsonUtil.getValue("username"), JsonUtil.getValue("password"));
        UserPage userpage = new UserPage(driver);
        userpage.userProfileClick();
    }
}