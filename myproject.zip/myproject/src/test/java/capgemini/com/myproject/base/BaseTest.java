package capgemini.com.myproject.base;

import capgemini.com.myproject.utilities.ExtentReportUtil;
import capgemini.com.myproject.factory.DriverFactory;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;
import capgemini.com.myproject.utilities.ConfigReader;

public class BaseTest {

    protected WebDriver driver;


    @BeforeMethod
    @Parameters("browser")
    public void setup(@Optional("chrome") String browser) {

        // If the browser is "chrome" (the default), we check if config.properties
        // suggests something else
        String configBrowser = ConfigReader.getProperty("browser");

        // Priority:
        // 1. If 'browser' parameter is NOT 'chrome', it means it was passed via XML ->
        // use it.
        // 2. If 'browser' is 'chrome' BUT config.properties has a value -> use config.
        // 3. Otherwise -> use 'chrome'.

        if (browser.equalsIgnoreCase("chrome") && configBrowser != null && !configBrowser.isEmpty()) {
            browser = configBrowser;
        }

        driver = DriverFactory.initDriver(browser);
        driver.get(ConfigReader.getProperty("url"));
    }

    @AfterMethod
    public void tearDown() {
        DriverFactory.quitDriver();
    }
}