package capgemini.com.myproject.utilities;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;

public class JsonUtil {

    private static JsonNode jsonData;

    static {
        try {
            ObjectMapper mapper = new ObjectMapper();
            jsonData = mapper.readTree(new File("src/test/java/capgemini/com/myproject/testdata/testdata.json"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String getValue(String key) {
        return jsonData.get(key).asText();
    }
}