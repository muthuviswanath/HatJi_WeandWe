package capgemini.com.myproject.utilities;

import com.aventstack.extentreports.*;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import capgemini.com.myproject.factory.DriverFactory;

import java.io.File;

public class ExtentReportUtil {

    private static ExtentReports extent;
    private static ThreadLocal<ExtentTest> test = new ThreadLocal<>();

    public static void initReport() {
        if (extent == null) {
            String reportPath = System.getProperty("user.dir") + "/reports/ExtentReport.html";
            File reportFile = new File(reportPath);
            if (!reportFile.getParentFile().exists()) {
                reportFile.getParentFile().mkdirs();
            }

            ExtentSparkReporter spark = new ExtentSparkReporter(reportPath);
            spark.config().setTheme(Theme.DARK);
            spark.config().setDocumentTitle("Automation Test Report");
            spark.config().setReportName("Functional Testing");

            extent = new ExtentReports();
            extent.attachReporter(spark);
            extent.setSystemInfo("Host Name", "Localhost");
            extent.setSystemInfo("Environment", "QA");
            extent.setSystemInfo("User Name", System.getProperty("user.name"));
            extent.setSystemInfo("OS", System.getProperty("os.name"));
            extent.setSystemInfo("Java Version", System.getProperty("java.version"));
        }
    }

    public static void flushReport() {
        if (extent != null) {
            extent.flush();
        }
    }

    public static void startTest(String testName) {
        ExtentTest extentTest = extent.createTest(testName);
        test.set(extentTest);
    }

    public static ExtentTest getTest() {
        return test.get();
    }

    public static void logStep(String message, boolean takeScreenshot) {
        if (getTest() != null) {
            if (takeScreenshot && DriverFactory.getDriver() != null) {
                String base64Code = ScreenshotUtil.captureScreenshotAsBase64(DriverFactory.getDriver());
                getTest().log(Status.INFO, message, 
                    MediaEntityBuilder.createScreenCaptureFromBase64String(base64Code).build());
            } else {
                getTest().log(Status.INFO, message);
            }
        }
    }

    public static void logPass(String message) {
        if (getTest() != null) {
            getTest().log(Status.PASS, message);
        }
    }

    public static void logFail(String message, Throwable t) {
        if (getTest() != null) {
            if (DriverFactory.getDriver() != null) {
                String base64Code = ScreenshotUtil.captureScreenshotAsBase64(DriverFactory.getDriver());
                getTest().log(Status.FAIL, message, 
                    MediaEntityBuilder.createScreenCaptureFromBase64String(base64Code).build());
            } else {
                getTest().log(Status.FAIL, message);
            }
            if (t != null) {
                getTest().fail(t);
            }
        }
    }

    public static void logSkip(String message) {
        if (getTest() != null) {
            getTest().log(Status.SKIP, message);
        }
    }
}
